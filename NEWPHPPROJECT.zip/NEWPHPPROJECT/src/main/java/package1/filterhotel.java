package package1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class filterhotel {

	
	WebDriver wd;
	By find_Best_Tours = By.xpath("//*[contains(text(),\"Find Best Tours\")]");
	By tours = By.linkText("Tours");
	By search_by_city = By.id("select2-tours_city-container");
	By search_city = By.xpath("//*[contains(text(),'Azerbaijan')]");
	By calender = By.id("date");
	By click_on_calender1 = By.xpath("//input[@class=\"dp form-control\"]");
    By date = By.xpath("//td[text()=\"1\"]");
    By travelers = By.xpath("//a[@class=\"dropdown-toggle dropdown-btn travellers waves-effect\"]");
	By adults_plus = By.xpath("(//*[name()='svg'])[8]");
	By adults_minus = By.xpath("(//*[name()='svg'])[9]");
	By childs_plus = By.xpath("(//*[name()='svg'])[11]");
	By childs_minus = By.xpath("(//*[name()='svg'])[10]");
	By search = By.xpath("//button[contains(@class, 'search')]");
   
	
	public void init1(WebDriver wd) {
		this.wd = wd;
		
	}
	public void Launch_PHP_Travels() {
		
		wd.get("https://www.phptravels.net/");
		wd.manage().window().maximize();
	}
	public void second_link() {
		wd.findElement(tours).click();
		
	}
	public void Find_best_tours() {
		wd.findElement(find_Best_Tours).click();
			
	}
	
	public void search_by_city() {
        wd.findElement(search_by_city).click();
 
    }
	public void search_city() {
		wd.findElement(search_city).click();
	}
	public void click_on_calender1() {
		wd.findElement(click_on_calender1);
	}
	public void calender() {
		wd.findElement(calender).click();
	}
	
	public void date() {
		wd.findElement(date).click();
	}
	public void travelers() {
		wd.findElement(travelers).click();
	}
	public void adults_plus() {
		wd.findElement(adults_plus).click();
	}
	public void adults_minus() {
		wd.findElement(adults_minus).click();
	}
	public void childs_plus() {
		wd.findElement(childs_plus).click();
	}
	public void childs_minus() {
		wd.findElement(childs_minus).click();
	}
	public void search() throws InterruptedException {
		wd.findElement(search).click();
		Thread.sleep(3000);
	
		
	}
	
}

