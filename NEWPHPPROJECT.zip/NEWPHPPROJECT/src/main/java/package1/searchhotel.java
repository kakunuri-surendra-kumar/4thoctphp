package package1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class searchhotel {

	WebDriver wd
	wd = new FirefoxDriver();
	By Hotels = By.linkText("(//a[@class=\"nav-link fadeout  waves-effect\"])[1]");
	By Search_for_best_hotels = By.xpath("//strong[text()=\"Search for best hotels\"]");
	By Search_By_City = By.xpath("//span[@class=\"select2-selection select2-selection--single\"]");
	By search_city = By.xpath("(//*[contains(text(),'Dubai')])[2]");
//	By Checkin_calender = By.id("checkin");
//	By Checkin_Date = By.xpath("(//td[text()=\"7\"])[1]");
//	By Checkout_Calender = By.xpath("checkout");
//	By Checkout_Date = By.xpath("(//td[contains(text(),'15')])[2]");
	By Travellers = By.xpath("//a[@class=\"dropdown-toggle dropdown-btn travellers d-flex align-items-center waves-effect\"]");
	//By Rooms_Plus = By.id("hotels_rooms");
	//By Rooms_Minus = By.xpath("div[class=\"roomDec\"] svg");
	By Add_Adults = By.xpath("(//div[@class=\"qtyInc\"])[2]");
	By Nationality = By.xpath("(//div[@class=\"form-floating\"])[3]");
	//By Country = By.id("nationality");
	
	By Search = By.xpath("//button[contains(@class, 'search_button')]");
	
	
	
	public void init1(WebDriver wd) {
		this.wd = wd;
		
	}
	public void Launch_PHP_Travels() {
		wd.get("https://www.phptravels.net/");
		wd.manage().window().maximize();
	}
	
	public  void second_link() {
		wd.findElement(Hotels).click();
	}
	
	
//	public void Launch_PHP_Travels() {
//		
//		wd.get("https://phptravels.net/tours/Baku/baku/05-10-2024/1/0/");
//	}

//   public void search1() throws InterruptedException {
//	   wd.findElement(search1).click();
//	   Thread.sleep(3000);
//   }
//   public void view_more() {
//	   wd.findElement(viewMore1).click();
//   }
	public void Search_for_best_hotels() {
		wd.findElement(Search_for_best_hotels).click();
	}
	
	public void Search_By_City() {
		wd.findElement(Search_By_City).click();
	}
	public void search_city() {
		wd.findElement(search_city).click();
	}
	public void Travellers() {
		wd.findElement(Travellers).click();
	}
	public void Add_Adults() {
		wd.findElement(Add_Adults).click();
	}
	public void Nationaility() {
		wd.findElement(Nationality).click();
	}
	public void Search() {
		wd.findElement(Search).click();
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
   
}