//package PHPHotels_stepdefinition;
//import static org.testng.Assert.assertEquals;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//
//import io.cucumber.java.Before;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import package1.filterhotel;
//
//public class filterhotel_stepdefinition {
//	WebDriver driver;
//	filterhotel obj = new filterhotel();
//	
//	@Before
//    public void setUp() {
//        // Initialize WebDriver here
//        driver = new FirefoxDriver();
//        driver.manage().window().maximize();
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//    }
//
//	@Given("The user is in chrome browser")
//	public void the_user_is_in_chrome_browser() {
//		//driver = new FirefoxDriver();
//		obj.init1(driver);
//
//		// throw new io.cucumber.java.PendingException();
//	}
//
//	@When("the user Launch the app PHP Travels")
//	public void the_user_launch_the_app_php_travels() {
//		// Write code here that turns the phrase above into concrete actions
//		obj.Launch_PHP_Travels();
//		// throw new io.cucumber.java.PendingException();
//	}
//
//	@Then("The user should navigate")
//	public void the_user_should_navigate() throws InterruptedException {
//	    // Write code here that turns the phrase above into concrete actions
//		obj.second_link();
//		WebElement cc = driver.findElement(By.xpath("//*[contains(text(),\"Find Best Tours\")]"));
//	String validText = "Find Best Tours";
//	assertEquals(validText, "Find Best Tours");
//    obj.Find_best_tours();
//    Thread.sleep(3000);
//	
//        }
//	@Then("user selects Baku as a city by using search by city")
//	public void user_selects_Baku_as_a_city_by_using_search_by_city() {
//		obj.search_by_city();
//		obj.search_city();
//	    
//	    //throw new io.cucumber.java.PendingException();
//	}
////	@And("user selects default date")
////    public void user_selects_defaults_date() {
////		obj.click_on_calender1();
////		obj.date();
////		obj.calender();
////		
////		//driver.findElement(By.id("date")).click();
////        //wd.findElement(By.id("calender")).click();
////    }
//
////    @And("the user selects a date")
////    public void the_user_selects_a_date() {
////    	obj.calender();
////        //driver.findElement(By.id("date")).click();
////    }
////	@And("I select the number of travelers")
////	public void i_select_the_number_of_travelers() {
////		obj.travelers();
////		obj.adults_minus();
////		obj.adults_minus();
////		obj.childs_plus();
////		obj.childs_minus();
//	
//	    
////	    throw new io.cucumber.java.PendingException();
////	}
//	@Then("I click on the search button")
//	public void i_click_on_the_search_button() throws InterruptedException {
//		obj.search();
//		Thread.sleep(5000);
//	    
//	   // throw new io.cucumber.java.PendingException();
//	}
//
//
//
//    }
//
//
