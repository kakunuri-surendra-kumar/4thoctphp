

package PHPHotels_stepdefinition;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import package1.searchhotel;

public class searchhotel_stepdefinition {
	
	WebDriver driver;
	searchhotel obj = new searchhotel();
	
	@Before
    public void setUp() {
        // Initialize WebDriver here
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

	@Given("The user is in chrome browser")
	public void the_user_is_in_chrome_browser() {
		//driver = new FirefoxDriver();
		obj.init1(driver);

		// throw new io.cucumber.java.PendingException();
	}

	@When("the user Launch the app PHP Travels")
	public void the_user_launch_the_app_php_travels() {
		// Write code here that turns the phrase above into concrete actions
		obj.Launch_PHP_Travels();
		// throw new io.cucumber.java.PendingException();
	}

	@And("The user should navigate")
	public void the_user_should_navigate() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		obj.second_link();
		WebElement cc = driver.findElement(By.xpath("//strong[text()=\"Search for best hotels\"]"));
	String validText = "Search for best hotels";
	assertEquals(validText, "Search for best hotels");
    obj.Search_for_best_hotels();
    Thread.sleep(3000);
	
        }
	@And("I enter city name in the destination field")
	public void i_enter_city_name_in_the_destination_field() {
		obj.Search_By_City();
		obj.search_city();
	}
	
	@When("I select check-in date as {string}")
    public void i_select_check_in_date_as(String checkInDate) {
        driver.findElement(By.name("checkin")).clear();
        driver.findElement(By.name("checkin")).sendKeys(checkInDate);
    }

    @When("I select check-out date as {string}")
    public void i_select_check_out_date_as(String checkOutDate) {
        driver.findElement(By.name("checkout")).clear();
        driver.findElement(By.name("checkout")).sendKeys(checkOutDate);
    }	
	

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	WebDriver wd;
//	searchhotel obj = new searchhotel();
//	
//	@Before
//    public void setUp() {
//        // Initialize WebDriver here
//        wd = new FirefoxDriver();
//        wd.manage().window().maximize();
//        
//        wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//    }
//	 @Given("I am on the PHP Travels Homepage")
//	    public void i_am_on_the_php_traqvels_homepage() {
//	       
//	        wd.manage().window().maximize();
//	        
//	        obj.init1(wd);
//	        obj.Launch_PHP_Travels();
//	    }

	    @When("the user clicks on the search button")
	    public void the_user_clicks_on_the_search_button() throws InterruptedException {
	        obj.Search();
	    }

//	    @When("the user clicks on view more")
//	    public void the_user_clicks_on_view_more() {
//	        obj.view_more();
//	    }
//	    @And("validate the text which is related to searched city")
//        public void validate_the_text_which_is_related_to_searched_city() {
//        	
//	    	WebElement title = wd.findElement(By.xpath("//div[@class=\"h3 fw-bold mb-0 py-1\"]"));
//	        Assert.assertEquals(title.getText(), "Baku City Tour");
//
//	        // Validate the price "From USD 0.00"
//	        WebElement price = wd.findElement(By.xpath("//span[contains(text(), 'From USD 0.00')]"));
//	        Assert.assertEquals(price.getText(), "From USD 0.00");
//	    }
//
//	    public void tearDown() {
//	        if (wd != null) {
//	            wd.quit();
//	        }
//	    }

	    
	}



