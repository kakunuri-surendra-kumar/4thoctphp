package Runner_class;
 
import org.junit.runner.RunWith;
 
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
 
 
@RunWith(Cucumber.class)
@CucumberOptions(
features="src/test/resource/phptravels/hotels.feature",
glue = "PHPHotels_stepdefinition",
plugin = {"pretty", "html:target/cucumber-reports.html"}
		
		)
 
public class runnerfile {
 
	
	
	}