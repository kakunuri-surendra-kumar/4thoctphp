package com.pages.RLL_240Testing_PhpTravels_Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PhpTravels_Homepage_lib {
	
	WebDriver wd;
	
	By Hotels = By.linkText("Hotels");
	
	
	public void init (WebDriver wd) {
		this.wd=wd;
		
	}
	public void Launch_PHP_Travels() {
		wd.get("https://www.phptravels.net/");
		wd.manage().window().maximize();
	}
	public  void second_link() {
		wd.findElement(Hotels).click();
	}



}
