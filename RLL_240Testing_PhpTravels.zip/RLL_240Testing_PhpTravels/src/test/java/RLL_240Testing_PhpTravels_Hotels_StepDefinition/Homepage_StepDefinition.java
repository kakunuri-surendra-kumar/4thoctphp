package RLL_240Testing_PhpTravels_Hotels_StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import static org.junit.Assert.*;

public class Homepage_StepDefinition {
    WebDriver driver;

    @Given("I am on the PHP Travels Homepage")
    public void i_am_on_the_php_travels_homepage() {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://phptravels.com");
    }

    @When("I click on {string} link")
    public void i_click_on_link(String linkText) {
        driver.findElement(By.linkText(linkText)).click();
    }

    @Then("I should be redirected to Hotels module")
    public void i_should_be_redirected_to_hotels_module() {
        String currentUrl = driver.getCurrentUrl();
        assertTrue(currentUrl.contains("/hotels"));
        
    }
}
