package Runner_package;
 
import org.junit.runner.RunWith;
 
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
 
 
@RunWith(Cucumber.class)
@CucumberOptions(
features="src/test/resource/PhpTravels_Feature/Homepage.feature",
glue = "Homepage_StepDefinition",
plugin = {"pretty", "html:target/cucumber-reports.html"}
		
		)
 
public class Runner_Class {
 
	
	
	}